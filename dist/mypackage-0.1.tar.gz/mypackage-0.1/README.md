# mypackage
This library was created as an eg.

##building this package locally
`python setup.py sdist`

## installing this package from Github
`pip install git+https://github.com/`

## updating this package from Github
`pip install --upgrade git+https://github.com/Hosana-Nxumalo/example-python-package.git`
